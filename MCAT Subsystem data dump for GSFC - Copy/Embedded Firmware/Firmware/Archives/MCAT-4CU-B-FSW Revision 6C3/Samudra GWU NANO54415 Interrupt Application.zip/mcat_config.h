/*
 * mcat_config.h - C++ header file for MCAT-4CU controller
 *
 * Copyright 2014-2015 The George Washington University. ALL RIGHTS RESERVED. Patents Pending
 * Author: Samudra Haque (SH), G19124781, N3RDX, samudra@gwu.edu, samudra.haque@gmail.com
 * 9/25/2014
 */

#ifndef MCAT_CONFIG_H_
#define MCAT_CONFIG_H_

//define DMA TIMER section relevant values
DWORD doPulseStack[USER_TASK_STK_SIZE];
DWORD uint32_counter = 0;
DWORD PulseCount = 0;
DWORD MaxCount = 1;
int TS1Count = 0;
bool Continuous = FALSE;
OS_SEM SemPulse;
OS_SEM SempTP;
int TSRD = 623; //default Time Slice Reference (TSR) value .147mS/.147mS/.147mS NANO54415 DMATIMER4 (matlab) 10/2/14
int TSR = TSRD; //utilize default produced

//default values
int MCHCD = 0;
int TPHCD = 14;
int TPLCD = 29;
int MCLCD = 44;
int EOCCD = 99954; //default values above give F=1 Hz.

//assigning timing components for this implementation
int MCHC = MCHCD;
int TPHC = TPHCD;
int TPLC = TPLCD;
int MCLC = MCLCD;
int EOCC = EOCCD;

//logic definitions
int HIGH=1; int NHIGH = 0;
int LOW=0; int NLOW = 1;

int countUP; //interrupt cycle




#ifdef TESTCU
#include <pins.h>
//GPIO PIN definition TESTCU
#define SW_RUNPMA Pins[23]
#define SW_TP1 Pins[12]
#define SW_P18L12 Pins[16]
#define SW_P18H12 Pins[25]
#define SW_P18L34 Pins[49]
#define SW_P18H34 Pins[50]
#else
#ifdef FLTCU
#include <pins.h>
//GPIO PIN definition FLTCU
#define SW_RUNPMA Pins[23]
#define SW_TP1 Pins[31]
//SW_P18L1-4 goes here
//SW_P18H1-4 goes here
#endif //FLTCU
#endif //TESTCU

/*
* TESTBUS (MOD54415), TESTCU (NANO54414)/FLTCU (NANO54414) I2C address
*/
#define CU_I2C_SLAVE_ADDR 0x26 // hardcoded I2C slave address.
#define TESTBUS_I2C_SLAVE_ADDR 0x24 //hardcoded I2C slave address

/*
* TESTCU/FLTCUsoftware build information
*/
#define CU_BUILD_MAJOR "5"  // numeric
#define CU_BUILD_MINOR "A" // alpha only
#define CU_VERSION_LEN 10 //numeric

/*
* TESTBUS software build information
*/
#define TB_BUILD_MAJOR "1"  // numeric
#define TB_BUILD_MINOR "A" // alpha only
#define TB_VERSION_LEN 10 //numeric

/*
* General Build Information
*/
#define BUILD_TIMESTAMP "201409251844"
#define BUILD_APP_TASKMON "M2CU-4G"
#define BUILD_APP_TITLE "Micro-Cathode Arc Thruster 2-Ch Control Unit - Remote Test Program"




// Safe copy of the DMATIMER4 matlab run

/*
 * NANO54415) DMA Timer Calc V2 for MCAT-4CU-B-V2K1
Samudra Haque (samudra@gwu.edu)
02-Oct-2014 16:08:01

[Chosen Impulse Timing Components]

t1    = 0.147 mS        (Pre-TP MC activation)
t2    = 0.147 mS        (TP activiation)
t3    = 0.147 mS        (Post TP MC activation)
tr    = 0.0008 mS    (assumed rise-time)
tf    = 0.0008 mS    (assumed fall time)
tpre  = 0.0024 mS    (assumed time for sensor/startup)
tpost = 0.0024 mS    (assumed time for sensor/shutdown)


[SINGLE SHOT PULSE]

Active Time (ta): 0.0004514

Events (inclusive of rise/fall times):
MCH 0 mS
TPH 0.1478 mS
TPL 0.2956 mS
MCL 0.4434 mS

[CONTINUOUS OPERATION]

Full Cycles: 2215
Partial Cycles: 0.330084
Idle Time per period (td): 6.72686e-05 mS
Active Time, per period (ta): 0.0004514

Events (inclusive of rise/fall times):
MCH 0 mS
TPH 0.1478 mS
TPL 0.2956 mS
MCL 0.4434 mS
EOC 0.451467 mS
Checking Total time period for 2215 full cycles is: 1 seconds

[MCF54415 DMA TIMER and Interrupt Count Values]

Time Step (TSR): 10 uS
REFVAL: 623
DIVIDER:1
PRESCALER:1

[TS Counter Values (MCHC, TPHC, TPLC, MCLC, EOCC)]
in ascending order of event time

         0         0
    0.0001   14.0000
    0.0003   29.0000
    0.0004   44.0000
    0.0005   45.0000

[Table of Frequency vs td (TS Counts)]
           1       99954
           2       49954
           3       33288
           4       24954
           5       19954
           6       16621
           7       14240
           8       12454
           9       11065
          10        9954
          11        9045
          12        8288
          13        7647
          14        7097
          15        6621
          16        6204
          17        5837
          18        5510
          19        5218
          20        4954
          21        4716
          22        4500
          23        4302
          24        4121
          25        3954
          26        3801
          27        3658
          28        3526
          29        3403
          30        3288
          31        3180
          32        3079
          33        2985
          34        2896
          35        2812
          36        2732
          37        2657
          38        2586
          39        2518
          40        2454
          41        2393
          42        2335
          43        2280
          44        2227
          45        2177
          46        2128
          47        2082
          48        2038
          49        1995
          50        1954*/



#endif /* MCAT_CONFIG_H_ */
